# Description

This resource is used to enable and disable Windows optional features.
This resource works on Nano Server.

## Requirements

- Target machine must be running a Windows client operating system, Windows
  Server 2012 or later, or Nano Server.
- Target machine must have access to the DISM PowerShell module.
