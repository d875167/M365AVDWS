# Description

Provides a mechanism to configure and manage multiple xService resources with
common settings but different names. This resource can only modify or delete
existing services. It cannot create services.
